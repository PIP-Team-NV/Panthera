export class Product {
    public Name: string;
    public Description: string;
    public date : string;
}
