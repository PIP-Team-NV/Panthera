import { Component, OnInit, Input, Renderer2, ChangeDetectorRef, forwardRef, ViewChild } from '@angular/core';
import { ControlValueAccessor, FormGroup, NG_VALUE_ACCESSOR, NG_VALIDATORS, FormControl } from '@angular/forms';
import { ControlMetadata, MetadataLibService } from 'metadata-lib-fcid';
import { MetadataServiceService } from '../services/metadata-service.service';
import { TabStripComponent } from '@progress/kendo-angular-layout';


@Component({
  selector: 'fcid-core-cascade',
  templateUrl: './core-cascade.component.html',
  styleUrls: ['./core-cascade.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CoreCascadeComponent),
    multi: true
  },
  { provide: NG_VALIDATORS, useExisting: forwardRef(() => CoreCascadeComponent), multi: true }
  ]
})
export class CoreCascadeComponent implements OnInit, ControlValueAccessor, ControlMetadata {

  @Input('field') public field: string;
  @Input('fieldData') public fieldData: string;
  @Input('fieldMetadata') public fieldMetadata: any;
  @Input() formGroupValue: FormGroup;
  @Input() classCode: string;
  @Input() parentClassNode: string;
  @Input() leafClassNode: string;
  @Input() otherCatColumn: string;
  @Input() otherCatClassCode: string;
  @Input() context: string;
  @Input() browseBtnText: string;
  @Input() serchBtnText: string
  @Input() loadMorebtnText: string;
  @Input() public load_More: string;
  @Input() public selectQuetes: string;
  @Input() public dontSeeQuetes: string;
  @Input() public selectbtntext: string;
  @Input() public classificationText: string;
  @Input() public explanation: string;
  @Input() public submit: string;
  @Input() public matchingText: string;
  @Input() public selectFollowtext: string;
  @Input() public matchingBrowsText: string;
  @Input() public bottomText: string;
  @Input() public findButtonText: string;

  @ViewChild('tabstrip') public tabstrip: TabStripComponent;

  htmlToAdd: any;
  serachtext: any;
  selectedSerachText: any;
  searchSelectedval: string;
  selectedValue: string;
  query: any;
  isEnabled = false;
  leafNode = false;
  isAllow = false;
  ingrLeafNode = false;
  isSearchLeafNode = false;
  isSelectLeafNodeSearch = false;
  isEnabledSearchLoadMore = false;
  isEnabledBrosweLoadMore = false;
  isSelected = false;
  isSelectedLeafNode = false;
  @Input() required: any;
  BreadCumptext: string;
  isSelectEnabled = false;
  defaultItem: any;
  classCodeIngrCat = "IngrCat";
  classCodeIngrCat1 = "IngrCat1";
  propagateChange = (_: any) => { };
  validateFn: any = () => { };
  public defaultBredCrumbObj: Array<{ name: string, Id: number, parentId: number, hasChildItems: boolean, classCode: string }> = [];
  public categoryArr: Array<{ name: string, Id: number, parentId: number, hasChildItems: boolean, classCode: string }>;
  public dataCategory: Array<{ name: string, Id: number, parentId: number, hasChildItems: boolean, classCode: string }> = [];
  public dataProducts: Array<{ name: string, Id: number, parentId: number, hasChildItems: boolean, classCode: string }> = [];
  public loadDataCategory: Array<{ name: string, Id: number, parentId: number, hasChildItems: boolean, classCode: string }> = [];
  public dataOrders: Array<{ name: string, Id: number, parentId: number, hasChildItems: boolean, classCode: string }> = [];
  public selectedCategory: { name: string, Id: number, parentId: number, hasChildItems: boolean, classCode: string };
  public property = false;
  public items: any[] = [{}];
  public breadCrumbArr: Array<{ name: string, Id: number, parentId: number, hasChildItems: boolean, classCode: string }> = [];
  public breadCrumbObj = {
    "name": "",
    "parentId": null,
    "Id": null,
    "hasChildItems": false,
    "classCode": ""
  };
  searchTabArr = [{}];
  itemsSearch = [];
  public checked: number = 3;
  public mode: string = 'absolute';
  public show: boolean = true;

  constructor(private metadataLibService: MetadataLibService, private metadataService: MetadataServiceService, public renderer: Renderer2, private changeDetectorRef: ChangeDetectorRef) {
  }

  ngOnInit() {
    this.metadataService.getFlyoutFileJSON().subscribe(data => {
      this.dataCategory = data["dataCategory"];
      this.dataProducts = data["dataProducts"];
      this.dataOrders = data["dataOrders"];
      this.items = data["items"];
      this.itemsSearch = data["itemsSearch"];
      this.loadDataCategory = data["loadDataCategory"];
      this.defaultBredCrumbObj = data["defaultBredCrumbObj"];
      this.formatDataCat(this.dataCategory);
      for (let i = 0; i < this.defaultBredCrumbObj.length; i++) {
        this.defaultBredCrumbObj[i].name = this.defaultBredCrumbObj[i].name + ">"
      }
      this.breadCrumbArr.push(this.defaultBredCrumbObj[0]);
    });

    if (this.fieldMetadata != undefined) {
      let classCode = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'classCode');
      this.classCode = classCode ? classCode : "";
      let leafClassNode = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'leafClassNode');
      this.leafClassNode = leafClassNode ? leafClassNode : "";
      let parentClassNode = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'parentClassNode');
      this.parentClassNode = parentClassNode ? parentClassNode : "";
      let otherCatColumn = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'otherCatColumn');
      this.otherCatColumn = otherCatColumn ? otherCatColumn : "";
      let otherCatClassCode = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'otherCatClassCode');
      this.otherCatClassCode = otherCatClassCode ? otherCatClassCode : "";
      let context = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'context');
      this.context = context ? context : "";
      let browseBtnText = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'browseBtnText');
      this.browseBtnText = browseBtnText ? browseBtnText : "";
      let findButtonText = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'findButtonText');
      this.findButtonText = findButtonText ? findButtonText : "";
      let serchBtnText = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'searchBtnText');
      this.serchBtnText = serchBtnText ? serchBtnText : "";
      let loadMorebtnText = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'loadMoreBtnText');
      this.loadMorebtnText = loadMorebtnText ? loadMorebtnText : "";
      let load_More = (this.load_More) ? this.load_More : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'loadMore');
      this.load_More = load_More ? load_More : "";
      let selectQuetes = (this.selectQuetes) ? this.selectQuetes : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'selectQuetes');
      this.selectQuetes = selectQuetes ? selectQuetes : "";
      let dontSeeQuetes = (this.dontSeeQuetes) ? this.dontSeeQuetes : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'dontSeeQuetes');
      this.dontSeeQuetes = dontSeeQuetes ? dontSeeQuetes : "";
      let selectbtntext = (this.selectbtntext) ? this.selectbtntext : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'selectBtnText');
      this.selectbtntext = selectbtntext ? selectbtntext : "";
      let classificationText = (this.classificationText) ? this.classificationText : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'classificationText');
      this.classificationText = classificationText ? classificationText : "";
      let explanation = (this.explanation) ? this.explanation : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'explanation');
      this.explanation = explanation ? explanation : "";
      let submit = (this.submit) ? this.dontSeeQuetes : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'submit');
      this.submit = submit ? submit : "";
      let matchingText = (this.matchingText) ? this.matchingText : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'matchingText');
      this.matchingText = matchingText ? matchingText : "";
      let selectFollowtext = (this.selectFollowtext) ? this.selectFollowtext : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'selectFollowText');
      this.selectFollowtext = selectFollowtext ? selectFollowtext : "";
      let matchingBrowsText = (this.matchingBrowsText) ? this.matchingBrowsText : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'matchingBrowseText');
      this.matchingBrowsText = matchingBrowsText ? matchingBrowsText : "";
      let bottomText = (this.bottomText) ? this.bottomText : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'bottomText');
      this.bottomText = bottomText ? bottomText : "";
      this.required = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'required') == "true" ? true : false;
    }
  }

  ngAfterViewInit() {

  }

  formIngr(value, ingrName) {
    const breadcrumbValue = Object.assign({}, value);
    breadcrumbValue.name = ingrName;
    if (this.isSelected == false) {
      if (breadcrumbValue.classCode == this.classCodeIngrCat) {
        if (breadcrumbValue.name) {
          breadcrumbValue.name = breadcrumbValue.name.replace('...', '');
        }
        this.breadCrumbArr.push(breadcrumbValue);
        this.isSelected = true;
      }
      else {
        if (breadcrumbValue.name) {
          breadcrumbValue.name = breadcrumbValue.name.replace('...', '');
        }
        this.breadCrumbArr.push(breadcrumbValue);
        this.isSelected = false;
      }
    }
    else {
      if (breadcrumbValue.classCode != this.classCodeIngrCat) {
        if (breadcrumbValue.name) {
          breadcrumbValue.name = breadcrumbValue.name.replace('...', '');
        }
        let lastElm = this.breadCrumbArr[this.breadCrumbArr.length - 1];
        if (lastElm.classCode == this.classCodeIngrCat) {
          this.breadCrumbArr.pop();
        }
        this.breadCrumbArr.push(breadcrumbValue);
        this.isSelected = false;
      } else {
        this.breadCrumbArr.pop();
        this.breadCrumbArr.push(breadcrumbValue);
      }
    }
  }

  openPopup() {
    this.isAllow = true;
  }

  formatDataCat(arr) {
    this.isEnabledBrosweLoadMore = false;
    for (let i = 0; i < arr.length; i++) {
      if (arr[i].hasChildItems == true) {
        if (!arr[i].name.includes("...")) {
          arr[i].name = arr[i].name + "...";
        }
        this.leafNode = false;
      }
      if (arr[i].classCode != this.classCodeIngrCat) {
        this.leafNode = false;
        this.ingrLeafNode = true;
      }
      else {
        if (this.ingrLeafNode == true) {
          this.leafNode = false;
          this.ingrLeafNode = false;
        } else {
          this.leafNode = true;
        }
      }
    }
    this.categoryArr = arr;
    if (this.categoryArr.length >= 5) {
      this.isEnabledBrosweLoadMore = true;
    }
  }

  loadMore() {
    for (let i = 0; i < this.loadDataCategory.length; i++) {
      if (this.loadDataCategory[i].hasChildItems == true) {
        this.loadDataCategory[i].name = this.loadDataCategory[i].name + "...";
        this.leafNode = false;
      }
      if (this.loadDataCategory[i].classCode == this.classCodeIngrCat1 || this.loadDataCategory[i].classCode != this.classCodeIngrCat1) {
        this.leafNode = false;
        this.ingrLeafNode = true;
      }
      else {
        if (this.ingrLeafNode == true) {
          this.leafNode = false;
          this.ingrLeafNode = false;
        } else {
          this.leafNode = true;
        }
      }
    }
    for (let i = 0; i < this.loadDataCategory.length; i++) {
      this.categoryArr.push(this.loadDataCategory[i]);
    }
    this.loadDataCategory = [];
  }

  changeText(e) {
    this.serachtext = this.formGroupValue.get(this.fieldData).value;
    if (this.serachtext == e && e != "") {
      this.searchTabArr = this.itemsSearch;
      if (this.searchTabArr.length >= 10) {
        this.isEnabled = true;
        this.isEnabledSearchLoadMore = true
      }
    } else {
      this.searchTabArr = [];
    }
  }

  submitSearchleafval() {
    this.searchSelectedval = this.formGroupValue.get(this.fieldData).value;
  }


  breadcrumbLinkClick(item) {
    let index = this.breadCrumbArr.indexOf(item);
    this.breadCrumbArr.length = index + 1;
    const breadcrumbItem = Object.assign({}, item);
    breadcrumbItem.name = breadcrumbItem.name.replace('>', '');
    this.categoryArr = [];
    this.bindValueToBreadCrumb(breadcrumbItem);
  }

  bindValueToBreadCrumb(item) {
    for (let i = 0; i < this.dataCategory.length; i++) {
      this.dataCategory[i].name = this.dataCategory[i].name.replace('...', '');
    }
    const cloneDataCategory = Object.assign([], this.dataCategory);
    var resultObject = this.search(item, cloneDataCategory);
    
    if (resultObject != undefined) {
      this.formatDataCat(this.dataCategory);
    } else {
      for (let i = 0; i < this.dataProducts.length; i++) {
        this.dataProducts[i].name = this.dataProducts[i].name.replace('...', '');
      }
      const clonedataProducts = Object.assign([], this.dataProducts);
      var resultObject = this.search(item, clonedataProducts);
      if (resultObject != undefined) {
        this.formatDataCat(this.dataProducts);
      } else {
        for (let i = 0; i < this.dataOrders.length; i++) {
          this.dataOrders[i].name = this.dataOrders[i].name.replace('...', '');
        }
        const clonedataOrders = Object.assign([], this.dataOrders);
        var resultObject = this.search(item, clonedataOrders);
        if (resultObject != undefined) {
          this.formatDataCat(this.dataOrders);
        }
      }
    }

  }

  search(nameKey, arr) {
    for (var i = 0; i < arr.length; i++) {
      if (arr[i].parentId === nameKey.Id) {
        return arr[i];
      }
    }
  }


  public onClose(event: any) {
    event.preventDefault();
  }

  public onTabSelect(event) {
  }

  onSelect({ item }) {
    if (item.text == "Search...") {
      this.property = true;
      console.log(item.text);
    }
    else {
      console.log("Wrong Value");
    }
  }

  selectSearchEvent(value) {
    this.selectedSerachText = value;
    this.isSelectLeafNodeSearch = true;
  }

  searchTextNavigate(value) {
    Promise.resolve(null).then(() => this.tabstrip.selectTab(0));
    for (let i = 0; i < this.dataCategory.length; i++) {
      this.dataCategory[i].name = this.dataCategory[i].name.replace('...', '');
    }
    const cloneDataCategory = Object.assign([], this.dataCategory);
    var resultObject = this.searchBrowseParent(value, cloneDataCategory);
    if (resultObject != undefined) {
      this.formatDataCat(this.dataCategory);
    } else {
      for (let i = 0; i < this.dataProducts.length; i++) {
        this.dataProducts[i].name = this.dataProducts[i].name.replace('...', '');
      }
      const clonedataProducts = Object.assign([], this.dataProducts);
      var resultObject = this.searchBrowseParent(value, clonedataProducts);
      if (resultObject != undefined) {
        this.formatDataCat(this.dataProducts);
      } else {
        for (let i = 0; i < this.dataOrders.length; i++) {
          this.dataOrders[i].name = this.dataOrders[i].name.replace('...', '');
        }
        const clonedataOrders = Object.assign([], this.dataOrders);
        var resultObject = this.searchBrowseParent(value, clonedataOrders);
        if (resultObject != undefined) {
          this.formatDataCat(this.dataOrders);
        }
      }
    }
  }

  searchBrowseParent(nameKey, arr) {
    for (var i = 0; i < arr.length; i++) {
      if (arr[i].Id == nameKey.Id) {
        return arr[i];
      }
      else if (arr[i].Id == nameKey.parentId) {
        const objarr = Object.assign({}, arr[i]);
        this.breadCrumbArr = [];
        objarr.name = objarr.name + ">";
        this.breadCrumbArr.unshift(objarr);
        for (let i = 0; i < this.dataCategory.length; i++) {
          const objDataCat = Object.assign({}, this.dataCategory[i]);
          if (objarr.parentId != undefined) {
            if (objDataCat.Id == objarr.parentId) {
              objDataCat.name = objDataCat.name + ">";
              this.breadCrumbArr.unshift(objDataCat);
              this.breadCrumbArr.unshift(this.defaultBredCrumbObj[0]);
            } else {
              for (let i = 0; i < this.dataProducts.length; i++) {
                const objDataPrd = Object.assign({}, this.dataProducts[i]);
                if (objDataPrd.Id == objarr.parentId) {
                  objDataPrd.name = objDataPrd.name + ">";
                  this.breadCrumbArr.unshift(objDataPrd);
                } else {
                  for (let i = 0; i < this.dataOrders.length; i++) {
                    const objDataOrder = Object.assign({}, this.dataOrders[i]);
                    if (objDataOrder.Id == objarr.parentId) {
                      objDataOrder.name = objDataOrder.name + ">";
                      this.breadCrumbArr.unshift(objDataOrder);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  browseSelectEvent(value) {
    this.isSelectedLeafNode = false;
    if (value.classCode == this.classCodeIngrCat) {
      this.isSelectedLeafNode = true;
    }
    if (value.classCode == this.classCodeIngrCat1) {
      this.categoryArr = [];
      this.formatDataCat(this.dataProducts);
      this.formIngr(value, value.name + ">");
    }
    else if (value.classCode != this.classCodeIngrCat && value.classCode != this.classCodeIngrCat1) {
      this.categoryArr = [];
      this.formatDataCat(this.dataOrders);
      this.formIngr(value, value.name + ">");
    }
    else {
      this.formIngr(value, value.name + ">>");
    }
    this.selectedValue = value.name;
  }

  selectedBrowseVal() {
    this.formGroupValue.controls[this.field].setValue(this.selectedValue);
    this.isAllow = false;
  }

  selectedSearchVal() {
    this.formGroupValue.controls[this.field].setValue(this.selectedSerachText.name);
    this.isAllow = false;
  }

  cancleEvent(){
    this.isAllow = !this.isAllow;
  }
  _controlValue: any;

  get controlValue() {
    return this._controlValue;
  }

  set controlValue(val: any) {
    if (val == undefined) {
      this._controlValue = this.defaultItem;
    } else {
      this._controlValue = val;
    }
    this.propagateChange(this._controlValue);
  }

  writeValue(value: any): void {
    if (value !== undefined) {
      this.controlValue = value;
    }
  }
  registerOnChange(fn: any): void {
    this.propagateChange = fn;
  }
  registerOnTouched() {

  }

  validate(c: FormControl) {
    return this.validateFn(c);
  }

}
