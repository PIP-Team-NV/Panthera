import { Component, OnInit, Input, forwardRef } from '@angular/core';
import { ControlValueAccessor, FormControl, FormControlName, FormGroup, NG_VALUE_ACCESSOR } from '@angular/forms';
import { MetadataLibService, lCI, ControlMetadata, KVP } from 'metadata-lib-fcid';
import { error } from '@angular/compiler/src/util';

@Component({
  selector: 'fcid-decimal',
  templateUrl: './decimal.component.html',
  styleUrls: ['./decimal.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => DecimalComponent),
    multi: true
  }
  ]
})
export class DecimalComponent implements OnInit, ControlValueAccessor, ControlMetadata {
  @Input('field')
  public field: string;
  @Input('fieldMetadata')
  public fieldMetadata: any;
  @Input() formGroupValue: FormGroup;
  defaultItem: any;
  @Input()
  public decimalValue: number;
  @Input()
  public min: number;
  @Input()
  public max: number;
  @Input()
  public step: number;
  @Input()
  public spinner: any;
  @Input() required: any;
  @Input() width: any;
  @Input() readonly: any;
  @Input() format: any;
  propagateChange = (_: any) => { };

  constructor(private metadataLibService: MetadataLibService) { }

  ngOnInit() {
    if (this.fieldMetadata != undefined) {
      this.decimalValue = parseInt((this.decimalValue) ? this.decimalValue : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'decimalValue'));
      let readonly = (this.readonly) ? this.readonly : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'readonly'); //need dynamic value
      this.readonly = readonly === "true" ? true : false;
      let textBoxWidth = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'width')
      this.width = textBoxWidth === "0px" || textBoxWidth === null || textBoxWidth === "0%" ? "" : textBoxWidth;
      this.required = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'required') == "true" ? true : false;
      this.min = parseInt((this.min) ? this.min : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'min'));
      this.max = parseInt((this.max) ? this.max : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'max'));
      this.format = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'format');
      this.spinner = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'spinner') == "true" ? true : false;
      this.step = parseInt((this.step) ? this.step : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'step'));
    }
  }

  _controlValue: any;

  get controlValue() {
    return this._controlValue;
  }

  set controlValue(val: any) {
    if (val == undefined) {
      this._controlValue = this.defaultItem;
    } else {
      this._controlValue = val;
    }
    this.propagateChange(this._controlValue);
  }

  writeValue(value: any): void {
    if (value !== undefined) {
      this.controlValue = value;
    }
  }
  registerOnChange(fn: any): void {
    this.propagateChange = fn;
  }
  registerOnTouched() {

  }

}
