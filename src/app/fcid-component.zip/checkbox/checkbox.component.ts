import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, ControlValueAccessor } from '@angular/forms';
import { ControlMetadata, MetadataLibService } from 'metadata-lib-fcid';

@Component({
  selector: 'fcid-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.scss']
})
export class CheckboxComponent implements OnInit, ControlValueAccessor, ControlMetadata {

  @Input() formGroupValue: FormGroup;
  @Input('field') public field: string;
  @Input('fieldMetadata') public fieldMetadata: any;
  @Input() readonly: any;
  @Input() width: any;
  @Input() required: any;
  propagateChange = (_: any) => { };
  defaultItem: any;

  constructor(private metadataLibService: MetadataLibService) { }

  ngOnInit() {
    if (this.fieldMetadata != undefined) {
      let readonly = (this.readonly) ? this.readonly : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'readonly'); //need dynamic value
      this.readonly = readonly === "true" ? true : false;
      let width = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'width')
      this.width = width === "0px" || width === null || width === "0%" ? "" : width;
      this.required = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'required') == "true" ? true : false;
    }
  }

  _controlValue: any;

  get controlValue() {
    return this._controlValue;
  }

  set controlValue(val: any) {
    if (val == undefined) {
      this._controlValue = this.defaultItem;
    } else {
      this._controlValue = val;
    }
    this.propagateChange(this._controlValue);
  }

  writeValue(value: any): void {
    if (value !== undefined) {
      this.controlValue = value;
    }
  }
  registerOnChange(fn: any): void {
    this.propagateChange = fn;
  }
  registerOnTouched() {

  }
}
