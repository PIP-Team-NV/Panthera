import { Component, OnInit, forwardRef, Input } from '@angular/core';
import { NG_VALUE_ACCESSOR, FormGroup, ControlValueAccessor } from '@angular/forms';
import { MetadataLibService, lCI, KVP, ControlMetadata } from 'metadata-lib-fcid';
import { MetadataServiceService } from '../services/metadata-service.service';

@Component({
  selector: 'fcid-cascade',
  templateUrl: './cascade.component.html',
  styleUrls: ['./cascade.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CascadeComponent),
    multi: true
  }
  ]
})
export class CascadeComponent implements OnInit, ControlValueAccessor, ControlMetadata {

  @Input('field')
  public field: string;
  @Input('fieldMetadata')
  public fieldMetadata: any;
  @Input('fieldData')
  public fieldData: any;
  @Input('fieldvalue')
  public fieldvalue: any;
  @Input()
  formGroupValue: FormGroup;
  @Input('orderby')
  orderby: string = 'asc';
  @Input()
  @Input() public parentText: string;
  @Input() public childText: string;
  @Input() public secChildText: string;
  @Input() required: any;
  listCoreItems: lCI[] = [];
  defaultItem: Array<number>;
  data: KVP[];
  listCoreItemsBackup = [];
  dropdownlist = [3, 2, 1];
  propagateChange = (_: any) => { };

  public dataProducts: Array<{ productName: string, productId: number, coreItemId: number }> = [];

  public dataOrders: Array<{ orderName: string, orderId: number, productId: number, }> = [];


  constructor(private metadataLibService: MetadataLibService, private metadataService: MetadataServiceService) { }

  ngOnInit() {
    if (this.fieldMetadata != undefined) {
      let data = MetadataLibService.getList(this.fieldMetadata);
      this.data = data ? data : [];
      let parentText = (this.parentText) ? this.parentText : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'parentText');
      this.parentText = parentText ? parentText : "";
      let childText = (this.childText) ? this.childText : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'childText');
      this.childText = childText ? childText : "";
      let secChildText = (this.secChildText) ? this.secChildText : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'secChildText');
      this.secChildText = secChildText ? secChildText : "";
      this.required = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'required') == "true" ? true : false;
      this.PrepareData();
    }
    this.metadataService.getCascadeJSON().subscribe(data => {
      this.dataProducts = data["product"];
      this.dataOrders = data["order"];
    });

  }

  private PrepareData() {

    this.listCoreItems = [];
    if (!this.data) return;
    if (this.orderby === 'asc') {
      this.data.sort((a, b) => {
        if (a.value.sort < b.value.sort) return -1;
        else if (a.value.sort > b.value.sort) return 1;
        else return 0;
      }).forEach(kvp => {
        var item: lCI = { coreItemId: parseInt(kvp.key, 10), coreItemValue: kvp.value.val };
        this.listCoreItems.push(item);
      });
    }
    else {
      this.data.sort((a, b) => {
        if (a.value.sort < b.value.sort) return 1;
        else if (a.value.sort > b.value.sort) return -1;
        else return 0;
      }).forEach(kvp => {
        var item: lCI = { coreItemId: parseInt(kvp.key, 10), coreItemValue: kvp.value.val };
        this.listCoreItems.push(item);
      });
    }
    console.log(this.listCoreItems);
    this.listCoreItemsBackup = this.listCoreItems;
  }

  public isDisabledProducts: boolean = true;
  public isDisabledOrders: boolean = true;

  public defaultItemCategories: { coreItemValue: string, coreItemId: number } = { coreItemValue: "Select category", coreItemId: null };

  public defaultItemProducts: { productName: string, productId: number } = { productName: "Select product", productId: null };

  public defaultItemOrders: { orderName: string, orderId: number } = { orderName: "Select order", orderId: null };



  public dataResultProducts: Array<{ productName: string, productId: number, coreItemId: number }>;

  public dataResultOrders: Array<{ orderName: string, orderId: number, productId: number, }>;

  public selectedCategory: { categoryName: string, categoryId: number };
  public selectedProduct: { productName: string, productId: number };
  public selectedOrder: { orderName: string, orderId: number };

  handleCategory(value) {
    this.selectedCategory = value;
    this.selectedProduct = undefined;
    this.selectedOrder = undefined;

    if (value == this.defaultItemCategories.coreItemId) {
      this.isDisabledProducts = true;
      this.dataResultProducts = [];
    } else {
      this.isDisabledProducts = false;
      this.dataResultProducts = this.dataProducts.filter((s) => s.coreItemId === value)
    }

    this.isDisabledOrders = true;
    this.dataResultOrders = [];
  }

  handleProductChange(value) {
    this.selectedProduct = value;
    this.selectedOrder = undefined;

    if (value == this.defaultItemProducts.productId) {
      this.isDisabledOrders = true;
      this.dataResultOrders = [];
    } else {
      this.isDisabledOrders = false;
      this.dataResultOrders = this.dataOrders.filter((s) => s.productId === value)
    }
  }

  handleOrderChange(value) {
    this.selectedOrder = value;
  }

  _controlValue: any;

  get controlValue() {
    return this._controlValue;
  }

  set controlValue(val: Array<number>) {
    if (val == undefined) {
      this._controlValue = this.defaultItem;
    } else {
      this._controlValue = val;
    }
    this.propagateChange(this._controlValue);
  }

  onChange(value) {
    this.controlValue = value;
  }

  handleFilter(value) {

  }
  public selectedItem() {
    return this.controlValue;
  }

  writeValue(value: any) {
    if (value !== undefined) {
      this.controlValue = value;
    }
  }

  registerOnChange(fn) {
    this.propagateChange = fn;
  }
  registerOnTouched() { }
}
