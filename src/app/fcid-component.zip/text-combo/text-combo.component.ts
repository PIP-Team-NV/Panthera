import { Component, OnInit, Input, forwardRef } from '@angular/core';
import { ControlValueAccessor, FormControl, FormControlName, FormGroup, NG_VALUE_ACCESSOR } from '@angular/forms';
import { MetadataLibService, lCI, ControlMetadata, KVP } from 'metadata-lib-fcid';
import { error } from '@angular/compiler/src/util';

@Component({
  selector: 'fcid-textcombo',
  templateUrl: './text-combo.component.html',
  styleUrls: ['./text-combo.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => TextComboComponent),
    multi: true
  }
  ]
})
export class TextComboComponent implements OnInit, ControlValueAccessor, ControlMetadata {

  @Input('field')
  public field: string;
  @Input('fieldMetadata')
  public fieldMetadata: any;
  @Input() formGroupValue: FormGroup;
  @Input() width: any;
  defaultItem: Array<number>;
  metadata: any;
  isRequiredEnabled: any;
  @Input()
  listCoreItems: lCI[] = [];
  listCoreItemsBackup: lCI[] = [];
  @Input()
  listMultiSelectEnabled: boolean = true;
  data: KVP[];
  @Input('orderby')
  orderby: string = 'asc';
  defaultEnabled = false;
  @Input() readonly: any;
  @Input() defaultText: string;
  public allowCustom: boolean = true;

  constructor(private metadataLibService: MetadataLibService) { }
  propagateChange = (_: any) => { };
  ngOnInit() {

    this.defaultEnabled = true;
    if (this.fieldMetadata != undefined) {
      this.data = MetadataLibService.getList(this.fieldMetadata);
      this.PrepareData();
    }
    let readonly = (this.readonly) ? this.readonly : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'readonly'); //need dynamic value
    try {
      this.readonly = readonly.toLowerCase() === "true" ? true : false;
    }
    catch (ex) {
      this.readonly = false;
    }

    let defaultText = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'defaultText');
    this.defaultText = defaultText ? defaultText : "";
    let textComboWidth = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'width')
    this.width = textComboWidth === "0px" || textComboWidth === null || textComboWidth === "0%" ? "" : textComboWidth;
    this.isRequiredEnabled = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'required') == "true" ? true : false;
    if (this.isRequiredEnabled == true) {
      this.defaultEnabled = false;
    } else {
      this.defaultEnabled = true;
    }

  }

  private PrepareData() {
    this.listCoreItems = [];
    if (!this.data) return;
    if (this.orderby === 'asc') {
      this.data.sort((a, b) => {
        if (a.value.sort < b.value.sort) return -1;
        else if (a.value.sort > b.value.sort) return 1;
        else return 0;
      }).forEach(kvp => {
        var item: lCI = { coreItemId: parseInt(kvp.key, 10), coreItemValue: kvp.value.val };
        this.listCoreItems.push(item);
      });
    }
    else {
      this.data.sort((a, b) => {
        if (a.value.sort < b.value.sort) return 1;
        else if (a.value.sort > b.value.sort) return -1;
        else return 0;
      }).forEach(kvp => {
        var item: lCI = { coreItemId: parseInt(kvp.key, 10), coreItemValue: kvp.value.val };
        this.listCoreItems.push(item);
      });
    }
    this.listCoreItemsBackup = this.listCoreItems;
  }

  public value: any = [];

  //Combobox implementation
  handleFilter(value) {
    this.listCoreItems = this.listCoreItemsBackup.filter((s) => s.coreItemValue.toLowerCase().indexOf(value.toLowerCase()) !== -1);
  }

  _controlValue: any;

  get controlValue() {
    return this._controlValue;
  }

  set controlValue(val: Array<number>) {
    if (val == undefined) {
      this._controlValue = this.defaultItem;
    } else {
      this._controlValue = val;
    }
    this.propagateChange(this._controlValue);
  }

  onChange(value) {
    this.controlValue = value;
  }

  public selectedItem() {
    return this.controlValue;
  }

  writeValue(value: any) {
    if (value !== undefined) {
      this.controlValue = value;
    }
  }

  registerOnChange(fn) {
    this.propagateChange = fn;
  }
  registerOnTouched() { }

}
