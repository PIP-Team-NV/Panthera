import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlyOutComponent } from './fly-out.component';

describe('FlyOutComponent', () => {
  let component: FlyOutComponent;
  let fixture: ComponentFixture<FlyOutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlyOutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlyOutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
