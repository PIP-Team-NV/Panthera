import { Component, OnInit, forwardRef, Input } from '@angular/core';
import { MetadataLibService, ControlMetadata } from 'metadata-lib-fcid';
import { NG_VALUE_ACCESSOR, ControlValueAccessor, FormGroup } from '@angular/forms';
import { MetadataServiceService } from '../services/metadata-service.service';

@Component({
  selector: 'fcid-fly-out',
  templateUrl: './fly-out.component.html',
  styleUrls: ['./fly-out.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => FlyOutComponent),
    multi: true
  }]
})
export class FlyOutComponent implements OnInit, ControlValueAccessor, ControlMetadata {

  @Input('field') public field: string;
  @Input('fieldMetadata') public fieldMetadata: any;
  @Input() formGroupValue: FormGroup;
  @Input() required: any;
  @Input() width: any;
  @Input() readonly: any;
  @Input() placeholderText: string;
  propagateChange = (_: any) => { };
  defaultItem: any;
  searchtext: string = '';
  level2text: any;
  level1text: any;
  isListVisible: boolean = false;
  flyoutData = [];

  constructor(private metadataLibService: MetadataLibService,private metadataService: MetadataServiceService) { }

  ngOnInit() {
    this.metadataService.getFlyoutFileJSON().subscribe(data => {
      this.flyoutData = data["flyoutData"];
    });

    if (this.fieldMetadata != undefined) {
    let readonly = (this.readonly) ? this.readonly : this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'readonly'); //need dynamic value
      this.readonly = readonly === "true" ? true : false;
      let textBoxWidth = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'width')
      this.width = textBoxWidth === "0px" || textBoxWidth === null || textBoxWidth === "0%" ? "" : textBoxWidth;
      this.required = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'required') == "true" ? true : false;
      let placeholderText = this.metadataLibService.getFieldAttributeParam([this.fieldMetadata], this.field, 'UIHint', 'placeholderText');
      this.placeholderText = placeholderText ? placeholderText : "";
      
    }
  }


  onSearchChange(event) {
    if (this.searchtext != undefined && event.data != null) {
      this.searchtext = this.searchtext + event.data;
    } else {
      this.searchtext = "";
    }
  }

  onSearchLevel1Data(event) {
    if (this.level1text != undefined && event.data != null) {
      this.level1text = this.level1text + event.data;
    } else {
      this.level1text = "";
    }
  }

  onSearchLeve2Data(event) {
    if (this.level2text != undefined && event.data != null) {
      this.level2text = this.level2text + event.data;
    } else {
      this.level2text = "";
    }
  }

  openList() {
    this.isListVisible = !this.isListVisible;
  }

  selectParentData(data) {
    this.formGroupValue.controls[this.field].setValue(data.name);
  }

  selectLevel1Data(data) {
    this.formGroupValue.controls[this.field].setValue(data.name);
  }

  selectLevel2Data(data) {
    this.formGroupValue.controls[this.field].setValue(data.name);
  }

  _controlValue: any;

  get controlValue() {
    return this._controlValue;
  }

  set controlValue(val: any) {
    if (val == undefined) {
      this._controlValue = this.defaultItem;
    } else {
      this._controlValue = val;
    }
    this.propagateChange(this._controlValue);
  }

  writeValue(value: any): void {
    if (value !== undefined) {
      this.controlValue = value;
    }
  }
  registerOnChange(fn: any): void {
    this.propagateChange = fn;
  }

  registerOnTouched() {

  }

}
