import { FcidVisibleDirective } from './fcid-visible.directive';

describe('FcidVisibleDirective', () => {
  // it('should create an instance', () => {
  //   const directive = new FcidVisibleDirective();
  //   expect(directive).toBeTruthy();
  // });
});
