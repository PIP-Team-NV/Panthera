import { ClientsBindingDirective } from './clients-binding.directive';

describe('ClientsBindingDirective', () => {
  it('should create an instance', () => {
    const directive = new ClientsBindingDirective();
    expect(directive).toBeTruthy();
  });
});
