import { SitesBindingDirective } from './sites-binding.directive';

describe('SitesBindingDirective', () => {
  it('should create an instance', () => {
    const directive = new SitesBindingDirective();
    expect(directive).toBeTruthy();
  });
});
