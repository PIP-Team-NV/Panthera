import { ChangeLogBindingDirective } from './change-log-binding.directive';

describe('ChangeLogBindingDirective', () => {
  it('should create an instance', () => {
    // const directive = new ChangeLogBindingDirective();
    // expect(directive).toBeTruthy();
  });
});
