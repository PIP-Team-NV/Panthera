// import { ChangeLogTipBindingDirective } from "./change-log-tip-binding.directive";

// describe('ChangeLogTipBindingDirective', () => {
//   it('should create an instance', () => {
//     const directive = new ChangeLogTipBindingDirective();
//     expect(directive).toBeTruthy();
//   });
// });
