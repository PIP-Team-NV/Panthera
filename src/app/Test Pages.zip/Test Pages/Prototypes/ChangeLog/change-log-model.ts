export class ChangeLogModel {
  action: string;
  date: string;
  item: string;
  newValue: string;
  oldValue: string;
  property: string;
  user: string;
}
